module.exports = function inventoryPost() {
  return { status: "ok" };
};
